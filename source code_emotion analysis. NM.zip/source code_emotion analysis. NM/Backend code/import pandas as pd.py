import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder

# Sample data
data = {
    'text': [
        "I am feeling very happy today!",
        "This is the worst day ever.",
        "I miss you so much it hurts.",
        "What a surprise! Didn’t expect that.",
        "I’m scared of what might happen."
    ],
    'emotion': ['joy', 'anger', 'sadness', 'surprise', 'fear']
}
df = pd.DataFrame(data)

# Encode emotions
encoder = LabelEncoder()
df['emotion_encoded'] = encoder.fit_transform(df['emotion'])

# Plot before and after
fig, axs = plt.subplots(2, 1, figsize=(10, 3))
for ax in axs:
    ax.axis('off')

# Before
axs[0].table(cellText=df[['text', 'emotion']].values, colLabels=['text', 'emotion'], loc='center')
axs[0].set_title("Before Encoding", fontweight='bold')

# After
axs[1].table(cellText=df[['text', 'emotion', 'emotion_encoded']].values, colLabels=['text', 'emotion', 'emotion_encoded'], loc='center')
axs[1].set_title("After Encoding", fontweight='bold')

plt.tight_layout()
plt.savefig("data_preprocessing_encoding.png", bbox_inches='tight')
