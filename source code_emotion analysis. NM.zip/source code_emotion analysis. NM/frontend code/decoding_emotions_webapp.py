
from flask import Flask, render_template_string

app = Flask(__name__)

html_content = """
<!DOCTYPE html>
<html lang='en'>
<head>
  <meta charset='UTF-8'>
  <meta name='viewport' content='width=device-width, initial-scale=1.0'>
  <title>Decoding Emotions | Sentiment Analysis</title>
  <link href='https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css' rel='stylesheet'>
  <link rel='preconnect' href='https://fonts.googleapis.com'>
  <link rel='preconnect' href='https://fonts.gstatic.com' crossorigin>
  <link href='https://fonts.googleapis.com/css2?family=Fira+Sans:wght@400;600;800&display=swap' rel='stylesheet'>
  <script src='https://cdn.jsdelivr.net/npm/chart.js'></script>
  <style>
    body {
      font-family: 'Fira Sans', sans-serif;
    }
    .hero-bg {
      background-image: url('https://images.unsplash.com/photo-1532634896-26909d0d4b7f?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80');
      background-size: cover;
      background-position: center;
    }
  </style>
</head>
<body class='text-gray-900 bg-gray-50'>

  <header class='hero-bg h-screen flex flex-col justify-center items-center text-white relative'>
    <div class='bg-black bg-opacity-70 p-10 rounded-2xl text-center backdrop-blur'>
      <h1 class='text-6xl font-extrabold mb-4'>Decoding Emotions</h1>
      <p class='text-2xl'>Sentiment Analysis of Social Media Conversations</p>
      <a href='#analyze' class='mt-8 inline-block bg-pink-600 hover:bg-pink-700 px-8 py-3 rounded-full text-white font-bold text-lg shadow-lg transition'>Start Analyzing</a>
    </div>
  </header>

  <section class='p-12 bg-white text-center'>
    <h2 class='text-4xl font-bold mb-6'>Why Emotion Analysis?</h2>
    <p class='max-w-4xl mx-auto text-lg'>Social media platforms are a treasure trove of emotional expression. With AI and NLP, we can decode users' emotions from their posts—text or image—and gain valuable insights for mental health monitoring, market analysis, and public mood tracking.</p>
  </section>

  <section id='analyze' class='p-12 bg-gradient-to-b from-indigo-50 to-white'>
    <h2 class='text-3xl font-bold text-center mb-10'>Analyze Emotions Now</h2>
    <div class='grid md:grid-cols-2 gap-10 max-w-6xl mx-auto'>
      <div class='bg-white p-6 rounded-xl shadow-lg'>
        <h3 class='text-2xl font-semibold mb-4'>Text Emotion Detector</h3>
        <textarea id='textInput' class='w-full border border-gray-300 p-4 rounded-lg mb-4' rows='6' placeholder='Type or paste a tweet or message...'></textarea>
        <button onclick='analyzeText()' class='w-full bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold transition'>Analyze Text</button>
        <div id='textResult' class='mt-6 text-lg font-medium text-center'></div>
      </div>
      <div class='bg-white p-6 rounded-xl shadow-lg'>
        <h3 class='text-2xl font-semibold mb-4'>Image Emotion Detector</h3>
        <input type='file' id='imageInput' accept='image/*' class='mb-4 block w-full text-sm text-gray-500'>
        <button onclick='analyzeImage()' class='w-full bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-semibold transition'>Analyze Image</button>
        <div id='imageResult' class='mt-6 text-lg font-medium text-center'></div>
      </div>
    </div>
  </section>

  <section class='p-12 bg-white'>
    <h2 class='text-3xl font-bold text-center mb-8'>Emotion Statistics</h2>
    <div class='max-w-3xl mx-auto'>
      <canvas id='emotionChart' height='200'></canvas>
    </div>
  </section>

  <footer class='text-center p-6 bg-gray-200 mt-10'>
    <p>&copy; 2025 Decoding Emotions. Built with Passion and AI.</p>
  </footer>

  <script>
    async function analyzeText() {
      const input = document.getElementById('textInput').value.trim();
      if (!input) {
        document.getElementById('textResult').innerText = "Please enter some text.";
        return;
      }
      document.getElementById('textResult').innerText = 'Predicted emotion: [Placeholder for ' + input + ']';
      updateChart('joy');
    }

    async function analyzeImage() {
      const file = document.getElementById('imageInput').files[0];
      if (!file) {
        document.getElementById('imageResult').innerText = 'Please upload an image first.';
        return;
      }
      document.getElementById('imageResult').innerText = 'Predicted emotion: [Placeholder for image analysis]';
      updateChart('surprise');
    }

    const ctx = document.getElementById('emotionChart').getContext('2d');
    const emotionChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Joy', 'Sadness', 'Anger', 'Fear', 'Disgust', 'Surprise'],
        datasets: [{
          label: 'Emotion Intensity',
          data: [0, 0, 0, 0, 0, 0],
          backgroundColor: [
            '#3b82f6', '#f97316', '#ef4444', '#8b5cf6', '#10b981', '#facc15'
          ]
        }]
      },
      options: {
        responsive: true,
        scales: {
          y: {
            beginAtZero: true,
            max: 10
          }
        }
      }
    });

    function updateChart(predictedEmotion) {
      const emotions = ['joy', 'sadness', 'anger', 'fear', 'disgust', 'surprise'];
      emotionChart.data.datasets[0].data = emotions.map(em => em === predictedEmotion.toLowerCase() ? 8 : 2);
      emotionChart.update();
    }
  </script>
</body>
</html>
"""

@app.route('/')
def index():
    return render_template_string(html_content)

if __name__ == '__main__':
    app.run(debug=True)
